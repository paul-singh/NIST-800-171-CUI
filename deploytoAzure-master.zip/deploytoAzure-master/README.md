NIST 800-171 CUI Demo App
====================
A simple CUI (controlled unclassified information) demo which shows that you can use the Azure Deploy Button without a custom Azure Resource Manager template (azuredeploy.json).

Created by Paul Singh, Microsoft. 04-03-2018

<a href="https://azuredeploy.net/" target="_blank"><img src="http://azuredeploy.net/deploybutton.png"/></a>
